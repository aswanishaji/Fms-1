package com.flp.fms.domain;

public class Actor 
{
	
	//private fields
	private int actor_Id;
	private String actor_First_Name;
	private String actor_last_Name;
	
	//No argument constructor
	public Actor()
	{
		
	}
	
	//Constructor with fields
	public Actor(int actor_Id, String actor_First_Name, String actor_last_Name)
	{
		super();
		this.actor_Id = actor_Id;
		this.actor_First_Name = actor_First_Name;
		this.actor_last_Name = actor_last_Name;
	}
	
	//getters and setters
	public int getActor_Id() {
		return actor_Id;
	}
	public void setActor_Id(int actor_Id) {
		this.actor_Id = actor_Id;
	}
	public String getActor_First_Name() {
		return actor_First_Name;
	}
	public void setActor_First_Name(String actor_First_Name) {
		this.actor_First_Name = actor_First_Name;
	}
	public String getActor_last_Name() {
		return actor_last_Name;
	}
	public void setActor_last_Name(String actor_last_Name) {
		this.actor_last_Name = actor_last_Name;
	}
	
	//Overridden toString()
	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", actor_First_Name=" + actor_First_Name + ", actor_last_Name="
				+ actor_last_Name + "]";
	}
	

}
