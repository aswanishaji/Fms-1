package com.flp.fms.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {
	//getting the language
	public List<Language> getLanguages();
	//getting the category
	public List<Category> getCategory();
	//adding film to repository
	public void addFilm(Film film);
	//getting all films from repository
	public Map<Integer,Film> getAllFilms();
	//searching film from the repository
	public Map<Integer, Film> searchfilm(int choice,Film film);
	//remove film from repository
	public void removeFilm(Film film);
	//modify the film in repository
	public void modifyFilm(Film film);

}
