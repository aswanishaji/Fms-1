package com.flp.fms.dao;
import java.util.Set;
import com.flp.fms.domain.Actor;

//interface for actor implementation 
public interface IActorDao {
	//get the values of actor
	public Set<Actor> getActors();
}
