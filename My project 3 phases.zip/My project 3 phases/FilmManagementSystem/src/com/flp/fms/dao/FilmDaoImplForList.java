package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao {
	
	HashMap<Integer,Film> film_Repository=new HashMap<>();
//setting languages
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1,"English"));
		languages.add(new Language(2,"Malayalam"));
		languages.add(new Language(3,"Hindi"));
		languages.add(new Language(4,"Tamil"));
		languages.add(new Language(5,"Telungu"));
		languages.add(new Language(6,"Kannada"));
		languages.add(new Language(7,"Marathi"));
		return languages;
	}
//setting categories
	@Override
	public List<Category> getCategory() {
		List<Category> categories=new ArrayList<>();
		categories.add(new Category(1,"Drama"));
		categories.add(new Category(2,"Comdey"));
		categories.add(new Category(3,"Horror"));
		categories.add(new Category(4,"Action"));
		categories.add(new Category(5,"Science Fiction"));
		categories.add(new Category(6,"Animation"));
		return categories;
	}
	//adding film to the repository
	@Override
	public void addFilm(Film film) {
		film_Repository.put(film.getFilm_Id(), film);
		
	}
	//getting all films from repository
	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return film_Repository;
	}
	
	//getting the searched film from repository
	@Override
	public Map<Integer, Film> searchfilm(int choice,Film film) {
		Map<Integer, Film>search_film=new HashMap<Integer, Film>();

			switch(choice)
			{
			//search by film id
			case 1:		
				for (Entry<Integer, Film> entry : film_Repository.entrySet()) {
				
						if(entry.getValue().getFilm_Id()==film.getFilm_Id())
						{	
						search_film.put(entry.getKey(), entry.getValue());
						
						}
					}
					
				break;
				//search by film name
			case 2:
				
				for (Entry<Integer, Film> entry : film_Repository.entrySet()) {
				{
					if(entry.getValue().getTitle().equals(film.getTitle()))
					{
						search_film.put(entry.getKey(), entry.getValue());
					}
				}
				}
				break;
				//search by actor
			case 3:
				Actor new_actor=new Actor();
				for(Actor sample_actor:film.getActors())
				{
					new_actor=sample_actor;
				}
				for (Entry<Integer, Film> entry : film_Repository.entrySet()) 
					{
						for(Actor actor:entry.getValue().getActors())
						{
							if(actor.getActor_First_Name().equals(new_actor.getActor_First_Name()))
							{
								search_film.put(entry.getKey(), entry.getValue());
							}
						}
					}
					break;
					
					//search by category
			case 4:
				
				for (Entry<Integer, Film> entry : film_Repository.entrySet()) 
				{
					if(entry.getValue().getCategory().getCategory_Name().equals(film.getCategory().getCategory_Name()))
					{	
						search_film.put(entry.getKey(), entry.getValue());
					}
				}
				break;
				
				//search by original language
			case 5:
				for (Entry<Integer, Film> entry : film_Repository.entrySet()) {
					if(entry.getValue().getOriginal_Language().getLanguage_Name().equals(film.getOriginal_Language().getLanguage_Name()))
					{
						search_film.put(entry.getKey(), entry.getValue());
					}
				}
				break;
				
				//search by rating
			case 6:
				for (Entry<Integer, Film> entry : film_Repository.entrySet()) 
				{
					if(entry.getValue().getRatings()==film.getRatings())
					{
						search_film.put(entry.getKey(), entry.getValue());
					}
				}
				break;	
			}
			//returning the film list obtained using search
		return search_film;
	}
	
	
	//removing the film from the repository
	@Override
	public void removeFilm(Film film) 
	{
		film_Repository.remove(film.getFilm_Id(), film);
	}
	
	//updating the film in the repository with keeping the film id as it is
	@Override
	public void modifyFilm(Film film) {
		film_Repository.put(film.getFilm_Id(), film);
		
	}
	

}
