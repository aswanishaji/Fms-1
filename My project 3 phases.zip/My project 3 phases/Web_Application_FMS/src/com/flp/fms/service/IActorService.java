package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

public interface IActorService {
	//getting the values from actor table
	ArrayList<Actor> displayActors();

	void addActor(Actor actor);
	Boolean updateActor(Actor tempActor);
	List<Actor> searchActor(Actor tempActor);

	boolean deleteActor(int id);

}
