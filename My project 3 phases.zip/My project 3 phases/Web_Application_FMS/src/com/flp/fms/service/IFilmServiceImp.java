package com.flp.fms.service;

import java.util.ArrayList;

import com.flp.fms.dao.FilmDAO;
import com.flp.fms.dao.FilmDAOImp;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class IFilmServiceImp implements IFilmService {
	FilmDAO filmdao=new FilmDAOImp();
	
	//adding film to the table
	@Override
	public void addFilm(Film film) {
		filmdao.addFilm(film);
	}
	
	//getting languages
	@Override
	public ArrayList<Language> displayLanguages() {
		return filmdao.displayLanguages();
	}
	
	//getting the categories of film
	@Override
	public ArrayList<Category> displayCategory() {
		return filmdao.displayCategory();
	}
	
	//getting all movies from the table
	@Override
	public ArrayList<Film> getAllfilms() {
		return filmdao.getAllfilms();
	}
	
	//removing the film from table based on the option selected
	@Override
	public Boolean deleteFilm(int filmid) {
		return filmdao.deleteFilm(filmid);
	}
	
	//returning the film which is searched
	@Override
	public ArrayList<Film> searchFilm(Film film) {
		return filmdao.searchFilm(film);
	}
	
	//modifying the film in table 
	@Override
	public Boolean updateFilm(Film film) {
		return filmdao.updateFilm(film);
	}
	

}
