package com.flp.fms.service;

import java.util.ArrayList;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmService {
	//getting the language
	ArrayList<Language> displayLanguages();
	//adding film to table
	void addFilm(Film film);
	//getting the category
	ArrayList<Category> displayCategory();
	//getting all films from table
	ArrayList<Film> getAllfilms();
	//remove film from table
	Boolean deleteFilm(int filmid);
	//searching film from the table
	ArrayList<Film> searchFilm(Film film);
	//modify the film in table
	Boolean updateFilm(Film film);
	
}
