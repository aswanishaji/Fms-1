package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.dao.IActorDAO;
import com.flp.fms.dao.IActorDAOImp;
import com.flp.fms.domain.Actor;

public class IActorServiceImp implements IActorService {

	IActorDAO actordao=new IActorDAOImp();
	//getting the actor values 
	@Override
	public ArrayList<Actor> displayActors() {
		return actordao.displayActors();
	}
	@Override
	public void addActor(Actor actor) {
		actordao.addActor(actor);
		
	}
	@Override
	public List<Actor> searchActor(Actor tempActor) {
		
		return actordao.searchActor(tempActor);
	}
	@Override
	public Boolean updateActor(Actor tempActor) {
		return actordao.updateActor(tempActor);
	}
	@Override
	public boolean deleteActor(int id) {
	
		return actordao.deleteActor(id);
	}

}
