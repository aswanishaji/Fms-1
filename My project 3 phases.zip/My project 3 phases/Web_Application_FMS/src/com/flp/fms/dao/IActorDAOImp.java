package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class IActorDAOImp implements IActorDAO {

	//establishing and getting connection with database called "fms"
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fms","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return connection;
	}
	
//displaying the actors 
	@Override
	public ArrayList<Actor> displayActors() {
		Connection con=getConnection();	
		ArrayList<Actor> actors=new ArrayList<Actor>();
		//using sql query retriving the actors in the database
		 String sql="select * from actor";
			try {
				PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					actors.add(new Actor(rs.getInt(1),rs.getString(2),rs.getString(3)));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return actors;
	}

	@Override
	public void addActor(Actor actor) {
		Connection con=getConnection();
		String sql="insert into actor(first_name,last_name)"
				+ "values(?,?)";
		
		 	PreparedStatement pst;
			try {
				pst = con.prepareStatement(sql);
				pst.setString(1,actor.getActor_First_Name());
				pst.setString(2,actor.getActor_last_Name());	
				int count=pst.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

	@Override
	public Boolean updateActor(Actor tempActor) {
		// establishing the connection
				Connection con=getConnection();
				Boolean flag=false;
			//query for updating the actor
				 String sql="Update actor Set first_name=?,last_name=? where actor_id="+tempActor.getActor_Id();
				 
				 try {
					 	PreparedStatement pst = con.prepareStatement(sql);
						pst.setString(1,tempActor.getActor_First_Name() );
						pst.setString(2,tempActor.getActor_last_Name() );	
						//execute the query for updating film table
						int count=pst.executeUpdate();
						flag=true;
							
						
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 return flag;
	}

	@Override
	public List<Actor> searchActor(Actor tempActor) {
		//establishing connection
				Connection con=getConnection();
				int count=0;
				//query for retriving actor from actor where it satisfies the following
				String sql="select * from actor where";
				ArrayList<Actor> actors=new ArrayList<Actor>();
				if(tempActor!=null)
				{
					//if the film id is their as condition
					if(tempActor.getActor_Id()>0)
					{
						
						sql+=" actor_id="+tempActor.getActor_Id();
						
						count=1;
					}
					
					//if there is firstname in condition
					if(tempActor.getActor_First_Name()!=null)
					{
						if(count==1)
						{
							sql+=" and first_name='"+tempActor.getActor_First_Name()+"'";
						}
						else
						{
							sql+=" first_name='"+tempActor.getActor_First_Name()+"'";
						}
						count=2;
					}
				
					//if there is lastname in condition
					if(tempActor.getActor_last_Name()!=null)
					{
						if(count==1||count==2)
						{
							sql+=" and getActor_last_Name()="+tempActor.getActor_last_Name();
						}
						else
						{
							sql+=" getActor_last_Name()="+tempActor.getActor_last_Name();
						}
						count=3;
					}
					
					//executing the query statement
					try {
						PreparedStatement pst=con.prepareStatement(sql);
						ResultSet rs=pst.executeQuery();
						//assign each film object obtained using the query to the hashmap
						while(rs.next())
						{
							Actor actor=new Actor();
							actor.setActor_First_Name(rs.getString(2));
							actor.setActor_Id(rs.getInt(1));
							actor.setActor_last_Name(rs.getString(3));
							
							actors.add(actor);
					} }catch (SQLException e) {

						e.printStackTrace();
					}
				
					
				}
				//return the entire search results
				return actors;
	}

	@Override
	public boolean deleteActor(int id) {
		//establishing connection
		Connection con=getConnection();
		boolean flag=false;
		//query for deleting the film object from film also the details from third party tables like film_actors and film_languages
		String sql= "DELETE actor,film_actor FROM actor LEFT JOIN film_actor ON actor.actor_id = film_actor.actor_id  WHERE actor.actor_id  =?" ;
				
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1,id);
			//executing the query statement
			int count=pst.executeUpdate();	
			if(count>0)
				flag=true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		return flag;
	}
}
