package com.flp.fms.dao;

import java.sql.Connection;
import java.util.ArrayList;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface FilmDAO {
	
	//getting the language
	ArrayList<Language> displayLanguages();
	
	//adding film to repository
	void addFilm(Film film);
	
	//getting the category
	ArrayList<Category> displayCategory();
	
	//getting all films from databse
	ArrayList<Film> getAllfilms();
	
	//remove film from database
	Boolean deleteFilm(int filmid);
	
	//searching film from the database
	ArrayList<Film> searchFilm(Film film);
	
	//modify the film in database
	Boolean updateFilm(Film film);
	
}