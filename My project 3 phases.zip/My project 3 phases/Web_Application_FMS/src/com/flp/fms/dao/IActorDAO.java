package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

public interface IActorDAO {
	//display actors list from actor
	ArrayList<Actor> displayActors();
	void addActor(Actor actor);
	List<Actor> searchActor(Actor tempActor);
	Boolean updateActor(Actor tempActor);
	boolean deleteActor(int id);

}
