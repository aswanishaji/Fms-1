package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IActorServiceImp;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImp;

/**
 * Servlet implementation class UpdateActorPage
 */
public class UpdateActorPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /*

	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IActorService actorService=new IActorServiceImp();
		//showing all actor in table
		ArrayList<Actor> actors=actorService.displayActors();
		PrintWriter out=response.getWriter();
		//for printing the films retrived  along with update link
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
				+ "</head>"
				+ "<h3> Update Actor Here</h3>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				+ "<table border=1>"
				+ "<tr>"
				+ "<th> Film Name </th>"
				+ "<th> Last Name </th>"
				+ "</tr>");
		
			for(Actor actor:actors){
				out.println("<tr>");
				out.println("<td>"+actor.getActor_First_Name()+"</td>");
				out.println("<td>"+actor.getActor_last_Name()+"</td>");
				
				out.println("<td><a href='UpdateActorServlet?actorid="+actor.getActor_Id()+"'>Update</a></td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
	}


}
