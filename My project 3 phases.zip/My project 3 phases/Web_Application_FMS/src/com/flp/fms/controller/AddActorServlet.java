package com.flp.fms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IActorServiceImp;

/**
 * Servlet implementation class AddActorServlet
 */
public class AddActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IActorService actorservice=new IActorServiceImp();
		Actor actor=new Actor();
		actor.setActor_First_Name(request.getParameter("firstname"));
		actor.setActor_last_Name(request.getParameter("lastname"));
		actorservice.addActor(actor);

	}

}
