package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;

/**
 * Servlet implementation class addActorPage
 */
public class addActorPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("<!DOCTYPE html>"
				+"<html>"
				+"<head>"
				+"<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
				+"<meta charset='ISO-8859-1'>"
		      +"<script type='text/javascript' src='Script/validate.js'></script>"
			+"	<title>Add Actor</title>"
			+"</head>"
			+"	<body>"
			+"	<form name='addactor' method='get' action='AddActorServlet'>"
			+"	<h3>Actor Registration Form</h3>"
			+"	<table>"
					+"<tr>"
					+"<td>First Name:</td>"
					+"<td><input type='text' name='firstname' size='20' onmouseout='return isValidTitle()'>"
					+"<div id='titleErr' class='errMsg'></div></td></td>"
					+"</tr>"
					
					+"<tr>"
					+"<td>Last Name:</td>"
					+"<td><input type='text' name='lastname' size='20' onmouseout='return isValidTitle()'>"
					+"<div id='titleErr' class='errMsg'></div></td></td>"
					+"</tr>"
					
	
					
				+"	<tr>"
						+"<td></td>"
						+"<td><input type='submit' value='Save'>"
						+"<input type='reset' value='Clear'>"
						+" </td>"
					+"</tr>"
					
				+"</table>"


				+"</form>"

			+"	</body>"
			+"	</html>");
	}

}
