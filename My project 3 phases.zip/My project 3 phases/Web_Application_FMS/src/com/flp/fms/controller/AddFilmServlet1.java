package com.flp.fms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImp;

/**
 * Servlet implementation class AddFilmServlet1
 */
//for retriving the fields that user inserted via addFilmPage
public class AddFilmServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService=new IFilmServiceImp();

		Film film=new Film();
		film.setTitle(request.getParameter("filmtitle"));
		film.setDescription(request.getParameter("filmdescription"));

		film.setRelease_Year(new Date(request.getParameter("releasedate")));	
		
		film.setRental_Duration(new Date(request.getParameter("rentaldate")));
		film.setLength(Integer.parseInt(request.getParameter("filmduration")));
		String [] actrlist=request.getParameterValues("actors");
		Set<Actor> actrs=new HashSet<>();
		for(String act:actrlist)
		{
			Actor actor1=new Actor();
			actor1.setActor_Id(Integer.parseInt(act));
			actrs.add(actor1);
		}
		//Set actrs=request.getParameter("actors");
		film.setActors(actrs);
		Double fees=Double.parseDouble(request.getParameter("filmreplacementcost"));
		film.setReplacement_Cost(fees);
		film.setRatings(Integer.parseInt(request.getParameter("rating")));
		film.setSpecial_Features(request.getParameter("filmspecialfeatures"));
		Language lang=new Language();
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("language")));
		film.setOriginal_Language(lang);
		String [] langlist=request.getParameterValues("languages");
		List<Language> langags=new ArrayList<>();
		for(String lang1:langlist)
		{
			Language langs=new Language();
			langs.setLanguage_Id(Integer.parseInt(lang1));
			langags.add(langs);
		}
		film.setLanguages(langags);
	    Category cat=new Category();
		cat.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(cat);
		//adding the newly added object to database
		filmService.addFilm(film);
		request.getRequestDispatcher("addFilmPage").forward(request, response);
	}

}
