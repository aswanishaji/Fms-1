package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IActorServiceImp;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImp;

/**
 * Servlet implementation class DeleteActorServlet
 */
public class DeleteActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	IActorService actorService=new IActorServiceImp();
		//getting all films database
		ArrayList<Actor> actors=actorService.displayActors();
		PrintWriter out=response.getWriter();	
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
				+ "</head>"
				
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				
				
				+ "<table border=1>"
				+ "<h3> Delete Actor</h3>"
				+ "<tr>"
				+ "<th> First Name </th>"
				+ "<th> Last Name </th>"
				+ "<th> Delete </th>"
				+ "</tr>");
		
			for(Actor actor:actors){
				out.println("<tr>");
				out.println("<td>"+actor.getActor_First_Name()+"</td>");
				out.println("<td>"+actor.getActor_last_Name()+"</td>");
				out.println("<td><a href='Delete_Actor_servlet?actorid="+actor.getActor_Id()+"'>Delete</a></td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
	}

}
