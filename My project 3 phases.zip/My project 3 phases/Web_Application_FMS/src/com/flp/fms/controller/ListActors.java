package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IActorServiceImp;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImp;

/**
 * Servlet implementation class ListActors
 */
public class ListActors extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IActorService actorService=new IActorServiceImp();
		//retrive all actors from database
		ArrayList<Actor> actors=actorService.displayActors();
		PrintWriter out=response.getWriter();
		
		//page displaying all actors
		out.println("<html>");
		out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
				+ "</head>"
				+ "<body>"
				+ "<h3> Actors </h3>"
				+ "<div style='margin-left:500px;'>  </div>"
				+ "<table border=1>"
				+ "<tr>"
				+ "<th> Actor Id </th>"
				+ "<th> First Name </th>"
				+ " <th> Last Name </th>"
				+ "</tr>");
		
			for(Actor actor:actors){
				out.println("<tr>");
				out.println("<td>"+actor.getActor_Id()+"</td>");
				out.println("<td>"+actor.getActor_First_Name()+"</td>");
				out.println("<td>"+actor.getActor_last_Name()+"</td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
			}
	
}
