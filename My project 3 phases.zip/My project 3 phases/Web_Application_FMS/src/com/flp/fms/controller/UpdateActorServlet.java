package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IActorServiceImp;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImp;

/**
 * Servlet implementation class UpdateActorServlet
 */
public class UpdateActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String actorid=request.getParameter("actorid");
		IActorService actorService=new IActorServiceImp();
	
		PrintWriter out=response.getWriter();
		Actor tempActor=new Actor();
		tempActor.setActor_Id(Integer.parseInt(actorid));
		//searching the actor which should be updated and retriving the data
		List<Actor> actors=actorService.searchActor(tempActor);
	Actor actor=new Actor();
		if(!actors.isEmpty())
			for(Actor act:actors)
				actor=act;
		out.println("<!DOCTYPE html>"
				+"<html>"
				+"<head>"
				+"<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
				+"<meta charset='ISO-8859-1'>"
				      +"<script type='text/javascript' src='Script/validate.js'></script>"
			+"	<title>Update Film</title>"
			+"</head>"
			+"	<body>"
			+"	<form name='updateActor' method='get'action='UpdatingActorServlet' >"
			+"	<h3>Actor Update Form</h3>"
			+"	<table>"
					+ "<tr><td><input type=text  name=actorid value='"+actorid+"' hidden><td><tr>"
					+"<tr>"
					+"<td>First Name:</td>"
					+"<td><input type='text' name='firstname' size='20' value="+actor.getActor_First_Name()+" onmouseout='return isValidTitle()'>"
					+"<div id='nameErr' class='errMsg'></div></td></td>"
					+"</tr>"
					
					+"<tr>"
					+"<td>Last Name:</td>"
					+"<td><input type='text' name='lastname' size='20' value="+actor.getActor_last_Name()+" onmouseout='return isValidTitle()'>"
					+"<div id='nameErr' class='errMsg'></div></td></td>"
					+"</tr>"

				+"	<tr>"
						+"<td></td>"
						+"<td><input type='submit' value='Update'>"
						+"<input type='reset' value='Clear'>"
						+" </td>"
					+"</tr>"
					
				+"</table>"


				+"</form>"

			+"	</body>"
			+"	</html>");
	}

}
