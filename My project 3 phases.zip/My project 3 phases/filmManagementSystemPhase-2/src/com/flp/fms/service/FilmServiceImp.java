package com.flp.fms.service;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.dao.FilmDaoImp;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImp implements IFilmService{
	private IFilmDao filmDao=new FilmDaoImp();
	//getting languages
	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}
	//getting the categories of film
	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}
	//adding film to the table
	@Override
	public void addFilm(Film film) {
		
		filmDao.addFilm(film);
		
		
	}
	
	//getting all movies from the table
	@Override
	public Map<Integer, Film> getAllFilms() {
		return filmDao.getAllFilms();
	}
	
	//returning the film which is searched
	@Override
	public HashMap<Integer, Film> searchfilm(Film film) {
	
		return  filmDao.searchfilm(film);
	}
	
	//removing the film from table based on the option selected
	@Override
	public void removeFilm(Film film) 
	{
		// TODO Auto-generated method stub
		filmDao.removeFilm(film);
	}

	//modifying the film in table 
	@Override
	public void modifyFilm(Film film) {
		filmDao.modifyFilm(film);
		
	}
	
}
