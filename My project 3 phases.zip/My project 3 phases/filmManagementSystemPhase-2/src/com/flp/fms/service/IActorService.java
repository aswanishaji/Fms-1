package com.flp.fms.service;

import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorService {
	//getting the values from actor table
	public  Set <Actor> getActors();
}
