package com.flp.fms.service;

import java.util.Set;

import com.flp.fms.dao.ActorDaoImp;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

public class ActorServiceImp implements IActorService{

	IActorDao actordao=new ActorDaoImp();
	//getting the actor values 
	@Override
	public Set<Actor> getActors() {
		return actordao.displayActors();
	}


	}

