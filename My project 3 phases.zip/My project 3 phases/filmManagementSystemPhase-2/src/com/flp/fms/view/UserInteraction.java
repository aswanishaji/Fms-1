package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;

public class UserInteraction {
	Scanner sc=new Scanner(System.in);
	Scanner sc1=new Scanner(System.in);
	
	//adding getting values into
	public Film AddFilm(List<Language> languages,List<Category> categories,Set<Actor> actors)
	{	boolean flag=false;
		String title=null;
		String description=null,specialfeatures=null;
		String releaseYear;
		String rentalduration;
		double replacementcost;
		int length,rate;
		Film film=new Film();
		
		//get the film title and validate and set the title
			do{
					
				System.out.println("Enter Film Title");
				title=sc.nextLine();
				flag=Validate.isValidTitle(title);
				if(flag==false)
				{
					System.out.println("Invalid Film Title!!!Please enter valid title");
				}
			}while(!flag);
			film.setTitle(title);
			
		// get the film description
			System.out.println("Enter Film Description");
			description=sc.nextLine();
			film.setDescription(description);
			
		//get and validate and set the release date
			 Date release_Year=null;
			 boolean flag1=false;
			do{
				
				
			do{
				
				System.out.println("Enter Release year:[dd-MMM-yyyy]");
				releaseYear=sc.next();
				flag=Validate.isValidDate(releaseYear);
				if(flag==false)
				{
					System.out.println("Invalid Release Year!!!Please enter valid year");
				}
			}while(!flag);
			Date today=new Date();
			release_Year=new Date(releaseYear);
			if(release_Year.before(today)||release_Year.equals(today))
				flag1=true;
			if(flag1==false)
				System.out.println("Invalid Date!!Date should before today's date");
			}while(!flag1);	
			film.setRelease_Year(release_Year);
		
		// get and validate the rental duration
			Date rental_duration=null;
			boolean rentalflag=false;
			do{
		do{
			
			System.out.println("Enter Rental duration:[dd-MMM-yyyy]");
			rentalduration=sc.next();
			flag=Validate.isValidDate(rentalduration);
			if(flag==false)
			{
				System.out.println("Invalid Rental duration!!!Please enter a valid one");
			}
		}while(!flag);
			rental_duration=new Date(rentalduration);
			if(rental_duration.after(release_Year))
			{
				rentalflag=true;
			}
			else
			{
				System.out.println("Invalid Date!!Date should be after release date");
			}
			}while(!rentalflag);
		
		film.setRental_Duration(rental_duration);
		
		//get and set length of movie
		do{
		System.out.println("Enter length of film in mins");
		length=sc.nextInt();
		flag=Validate.isValidLength(length);
		if(flag==false)
		{
			System.out.println("Invalid length!!!length in mins[0-1000]");
		}
		}while(!flag);
		film.setLength(length);
		
		//get and set the replacement cost
		do{
		System.out.println("Enter Replacement cost");
		replacementcost=sc.nextDouble();
		flag=Validate.isValidReplacementCost(replacementcost);
		if(flag==false)
			System.out.println("Please enter a valid cost");
		}while(!flag);
		film.setReplacement_Cost(replacementcost);
		
		//get and set the rating
		do{
			System.out.println("Enter ratings[1-5]");
			rate=sc.nextInt();
			flag=Validate.isValidRating(rate);
			if(flag==false)
			{
				System.out.println("Invalid rating!!!rating in between 1-5");
			}
			}while(!flag);
		film.setRatings(rate);
		
		//Get and set special features
		System.out.println("Enter Special Features");
		specialfeatures=sc1.nextLine();
		film.setSpecial_Features(specialfeatures);
		
		//Get and set the actors
		String choice_actor;
		Set<Actor> actors2=new HashSet<>();
		do{
			System.out.println("Enter Actors:");
			Actor actor=selectActors(actors);
			actors2.add(actor);	
			System.out.println("Wish to add More Actors?[y|n]");	
			choice_actor=sc.next();
		}while(choice_actor.charAt(0)=='y'||choice_actor.charAt(0)=='Y');
		
		film.setActors(actors2);
		
		//Get and set original language
		System.out.println("Enter original Language");
		Language originallang=selectLanguage(languages);
		film.setOriginal_Language(originallang);
		
		boolean flag_lang=false;
		String choice;
		
		
		//Get and set the set of languages
		List<Language> languages2=new ArrayList<>();
		do{
			System.out.println("Enter the languages:");
			Language language2=selectLanguage(languages);
			flag_lang=Validate.checkDuplicateLanguage(languages2, language2);
			if(flag_lang==false)
				languages2.add(language2);
			else
				System.out.println("Its already in the list,Please add other language");
			System.out.println("Wish to add More Languages?[y|n]");	
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		
		film.setLanguages(languages2);
		
		//Get and set category
		System.out.println("Enter Category");
		Category category=selectCategory(categories);
		film.setCategory(category);
		return film;
	}
	
//select the language and check whether the option is valid or not
	public Language selectLanguage(List<Language> languages)
	{
		Language sel_language=null;
		boolean flag_lang=false;
		do{
		for(Language language:languages)
			System.out.println(language.getLanguage_Id()+" "+language.getLanguage_Name());
		System.out.println("Choose Language");
		int lang_id=sc.nextInt();
		for(Language language:languages)
		{
			if(language.getLanguage_Id()==lang_id)
				{
				sel_language=language;
				flag_lang=true;
					break;
				}
			
		}
		if(flag_lang==false)
		{
			System.out.println("Provide the languages in the list");
		}
		}while(!flag_lang);
		return sel_language;
		
	}
	//select the category and check whether the option is valid or not
	public Category selectCategory(List<Category> categories)
	{
		Category sel_category=null;
		boolean flag_cat=false;
		do{
		for(Category category:categories)
			System.out.println(category.getCategory_Id()+" "+category.getCategory_Name());
		System.out.println("Choose Category");
		int cat_id=sc.nextInt();
		for(Category category:categories)
		{
			if(category.getCategory_Id()==cat_id)
				{
				sel_category=category;
				flag_cat=true;
					break;
				}
			
		}
		if(flag_cat==false)
		{
			System.out.println("Provide the languages in the list");
		}
		}while(!flag_cat);
		return sel_category;
		
	}
	//select the actors and check whether the option is valid or not
	public Actor selectActors(Set<Actor> actors)
	{
		Actor sel_actor=null;
		boolean flag_actor=false;
		do{
		for(Actor actor:actors)
			System.out.println(actor.getActor_Id()+" "+actor.getActor_First_Name()+actor.getActor_last_Name());
		System.out.println("Choose Actor");
		int act_id=sc.nextInt();
		for(Actor actor:actors)
		{
			if(actor.getActor_Id()==act_id)
				{
				sel_actor=actor;
				flag_actor=true;
					break;
				}
			
		}
		if(flag_actor==false)
		{
			System.out.println("Provide the languages in the list");
		}
		}while(!flag_actor);
		return sel_actor;
		
	}

	//printing all the films
	public void getAllFilms(Collection<Film> lst) {
		
		System.out.println("Film Id \t  Film Actors \t \t  Original Language \t Languages \t \t Description \t \t Special Features \t Category \t Release Date \t \t  Rental Date \t \tReplacement Cost \t Duration \t Ratings");
		for(Film film:lst){
			
			String languages="";
			for(Language language:film.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			String actors="";
			for(Actor actor:film.getActors())
				actors=actors+actor.getActor_First_Name()+actor.getActor_last_Name()+",";
			System.out.println(film.getFilm_Id() + "\t" +film.getTitle() + "\t"+actors + "\t"+film.getOriginal_Language()+"\t"+	languages+"\t"+	film.getDescription()+"\t"+film.getSpecial_Features()+"\t"+film.getCategory()+"\t"+film.getRelease_Year()+"\t"+film.getRental_Duration()+"\t"+film.getReplacement_Cost()+"\t"+film.getLength()+"\t"+film.getRatings());
			}
	}
	



//modifying film
public Film modifyFilm(Collection<Film> lst,int choice,List<Language> languagess,List<Category> categoriess,Set<Actor> actorss)
{
	Film updated_film=new Film();
	int flag = 0;
	switch(choice)
	{
	case 1:
		//search based on rating for modify
			System.out.println("Enter the Rating");
			int rate=sc.nextInt();
			for(Film film:lst)
			{
				if(film.getRatings()==rate)
				{
					flag=1;
					System.out.println("Film Id \t  Film Actors \t \t  Original Language \t Languages \t \t Description \t \t Special Features \t Category \t Release Date \t \t  Rental Date \t \tReplacement Cost \t Duration \t Ratings");
					flag=1;	
					String languages="";
					for(Language language:film.getLanguages())
						languages=languages+language.getLanguage_Name()+",";
					String actors="";
					for(Actor actor:film.getActors())
						actors=actors+actor.getActor_First_Name()+actor.getActor_last_Name()+",";
					System.out.println(film.getFilm_Id() + "\t" +film.getTitle() + "\t"+actors + "\t"+film.getOriginal_Language()+"\t"+	languages+"\t"+	film.getDescription()+"\t"+film.getSpecial_Features()+"\t"+film.getCategory()+"\t"+film.getRelease_Year()+"\t"+film.getRental_Duration()+"\t"+film.getReplacement_Cost()+"\t"+film.getLength()+"\t"+film.getRatings());				
					updated_film=AddFilm(languagess, categoriess, actorss);
					updated_film.setFilm_Id(film.getFilm_Id());
				}
			}
			if(flag==0)
			{
				System.out.println("Film not found");
			}
			break;
	case 2:
		//search done based on film name
		System.out.println("Enter Film Name");
		String film=sc.next();
		for(Film film1:lst)
		{
		if(film1.getTitle().equals(film))
		{
			flag=1;
			System.out.println("Film Id \t  Film Actors \t \t  Original Language \t Languages \t \t Description \t \t Special Features \t Category \t Release Date \t \t  Rental Date \t \tReplacement Cost \t Duration \t Ratings");
			flag=1;	
			String languages="";
			for(Language language:film1.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			String actors="";
			for(Actor actor:film1.getActors())
				actors=actors+actor.getActor_First_Name()+actor.getActor_last_Name()+",";
			System.out.println(film1.getFilm_Id() + "\t" +film1.getTitle() + "\t"+actors + "\t"+film1.getOriginal_Language()+"\t"+	languages+"\t"+	film1.getDescription()+"\t"+film1.getSpecial_Features()+"\t"+film1.getCategory()+"\t"+film1.getRelease_Year()+"\t"+film1.getRental_Duration()+"\t"+film1.getReplacement_Cost()+"\t"+film1.getLength()+"\t"+film1.getRatings());				
			 updated_film=AddFilm(languagess, categoriess, actorss);
			 updated_film.setFilm_Id(film1.getFilm_Id());
		}
		}
	if(flag==0)
	{
		System.out.println("Film not found");
	}
	break;
	case 3:
		//search based on release date
		System.out.println("Enter Release Date");
		String date=sc.next();
		Date dt=new Date(date);
		for(Film film1:lst)
		{
		if(film1.getRelease_Year().equals(dt))
		{
			flag=1;
			System.out.println("Film Id \t  Film Actors \t \t  Original Language \t Languages \t \t Description \t \t Special Features \t Category \t Release Date \t \t  Rental Date \t \tReplacement Cost \t Duration \t Ratings");
			flag=1;	
			String languages="";
			for(Language language:film1.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			String actors="";
			for(Actor actor:film1.getActors())
				actors=actors+actor.getActor_First_Name()+actor.getActor_last_Name()+",";
			System.out.println(film1.getFilm_Id() + "\t" +film1.getTitle() + "\t"+actors + "\t"+film1.getOriginal_Language()+"\t"+	languages+"\t"+	film1.getDescription()+"\t"+film1.getSpecial_Features()+"\t"+film1.getCategory()+"\t"+film1.getRelease_Year()+"\t"+film1.getRental_Duration()+"\t"+film1.getReplacement_Cost()+"\t"+film1.getLength()+"\t"+film1.getRatings());				
			 updated_film=AddFilm(languagess, categoriess, actorss);
			 updated_film.setFilm_Id(film1.getFilm_Id());
		}
		}
	if(flag==0)
	{
		System.out.println("Film not found");
	}
	break;
	}
	return updated_film;
	}







//remove film 
public Film removeFilm(Collection<Film> lst,int choice)
{
	int flag = 0;
	switch(choice)
	{
	case 1:
		//remove by rating
			System.out.println("Enter the Rating");
			int rate=sc.nextInt();
			for(Film film:lst)
			{
				if(film.getRatings()==rate)
				{
					flag=1;
					return film;
				}
			}
			if(flag==0)
			{
				System.out.println("Film not found");
			}
			break;
	case 2:
		//remove by film name
		System.out.println("Enter Film Name");
		String film=sc.next();
		for(Film film1:lst)
		{
		if(film1.getTitle().equals(film))
		{
			flag=1;
			return film1;
		}
		}
	if(flag==0)
	{
		System.out.println("Film not found");
	}
	break;
	case 3:
		//remove by release date
		System.out.println("Enter Release Date");
		String date=sc.next();
		Date dt=new Date(date);
		for(Film film1:lst)
		{
		if(film1.getRelease_Year().equals(dt))
		{
			flag=1;
			return film1;
		}
		}
	if(flag==0)
	{
		System.out.println("Film not found");
	}
	break;
	}
	return null;
	}

//searching film based on multiple choices
public Film SearchFilm(List<Language> languages,List<Category> categories,Set<Actor> actors) 
{
	Film newfilm=new Film();
	String ch;
	
	int id=0;
	do{
		//menu for search
		menuSearchSelection();
		int choice;
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:	
			//based on film id
			 System.out.println("Enter the film id");
			 id=sc.nextInt();
			 newfilm.setFilm_Id(id);
			break;
		case 2:
			//based on film name
			System.out.println("Enter Film Name");
			String film=sc.next();
			newfilm.setTitle(film);
			break;
		case 3:
			//based on film actor
			System.out.println("Enter Actor");
			Actor actor=selectActors(actors);
			newfilm.setActors(actors);	
			break;		
		case 4:
			//based on category
			System.out.println("Enter Category");
			Category catgry=selectCategory(categories);
			newfilm.setCategory(catgry);
			break;
		case 5:
			//based on language
			System.out.println("Enter Lanugage");
			Language lang=selectLanguage(languages);
			newfilm.setOriginal_Language(lang);
			break;
		case 6:
			//based on rating
			System.out.println("Enter Rating");
			int rating=sc.nextInt();
			newfilm.setRatings(rating);
			break;
		}
		System.out.println("Do you want to add more options?");
		ch=sc.next();
	}while(ch.charAt(0) =='Y'|| ch.charAt(0)=='y');
	return newfilm;
}
//menu search for a film
public static void menuSearchSelection()
{
	
	System.out.println("\t\t Search Menu");
	System.out.println("1. Search Film by Film Id");
	System.out.println("2. Search Film by Film Name");
	System.out.println("3. Search Film by Actor");
	System.out.println("4. Search Film by Category");
	System.out.println("5. Search Film by Language");
	System.out.println("6. Search Film by Rating");
	
}



}
