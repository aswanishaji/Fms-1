package com.flp.fms.view;

import java.util.Collection;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImp;
import com.flp.fms.service.FilmServiceImp;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass {

	public static void main(String[] args)
	{
		//object creation of userinteraction
		UserInteraction ui=new UserInteraction();
		
		//object creation of filmservice for film manipulation
		IFilmService filmservice=new FilmServiceImp();
		
		//object creation of actorservice for actor manipulation
		IActorService actorservice=new ActorServiceImp();
		String choice1,choice3;
		do{
		//display Main Menu
		menuSelection();
		int choice;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Choice:");
		choice=sc.nextInt();
		switch(choice)
		{
		//add film
		case 1: 
			
				//get the film fields from user through userinteraction addfilm
				Film film=ui.AddFilm(filmservice.getLanguages(),filmservice.getCategory(),actorservice.getActors());
			
				//adding the film object into databse via service to dao
				filmservice.addFilm(film);		
				break;
				
		//modify film
		case 2: do{
					menuModifySelection();
					int choicem;
					choicem=sc.nextInt();
					//getting all films from repository
					Map<Integer,Film> filmList2=filmservice.getAllFilms();
					Collection<Film> lst2=filmList2.values();
					
					//getting the object by comparing it with option from userinteraction
					Film f=ui.modifyFilm(lst2,choicem,filmservice.getLanguages(),filmservice.getCategory(),actorservice.getActors());
					
					//retriving the object from dao
					filmservice.modifyFilm(f);
					System.out.println("Do you want to modify again(y/n)");
					choice3=sc.next();
				}while(choice3.charAt(0)=='y'||choice3.charAt(0)=='Y');
				break;
				
		//remove film
		case 3:
				do{
					menuRemoveSelection();
					int choice2;
					choice2=sc.nextInt();
					
					//getting all films from dao
					Map<Integer,Film> filmList2=filmservice.getAllFilms();
					Collection<Film> lst2=filmList2.values();
					
					//getting the film object to be removed from user
					Film f=ui.removeFilm(lst2,choice2);
					
					//removing the film specified from database
					filmservice.removeFilm(f);
					System.out.println("Do you want to remove again(y/n)");
					choice3=sc.next();
				}while(choice3.charAt(0)=='y'||choice3.charAt(0)=='Y');
					break;
					
		//list all films	
		case 4: 	
					//getting all films 
					Map<Integer,Film> filmList=filmservice.getAllFilms();
					Collection<Film> lst=filmList.values();
					ui.getAllFilms(lst);
					break;
					
		//search film
		case 5:		do{
						//reading the option based input from user
						Film f=ui.SearchFilm(filmservice.getLanguages(),filmservice.getCategory(),actorservice.getActors());	
					
						//searching it in the database
						Map<Integer,Film> filmList3=filmservice.searchfilm(f);
						Collection<Film> lst2=filmList3.values();
						
						//printing the searched data
						System.out.println("Film Id \t Film Title \t\t Film Actors \t \t  Original Language \t Languages \t \t Description \t \t Special Features \t Category \t Release Date \t \t  Rental Date \t \tReplacement Cost \t Duration \t Ratings");
						for(Film search_film:lst2)
						{
						String languages="";
						for(Language language:search_film.getLanguages())
							languages=languages+language.getLanguage_Name()+",";
						String actors="";
							for(Actor actor:search_film.getActors())
									actors=actors+actor.getActor_First_Name()+actor.getActor_last_Name()+",";
						System.out.println(search_film.getFilm_Id() + "\t" +search_film.getTitle() + "\t"+actors + "\t"+search_film.getOriginal_Language()+"\t"+	languages+"\t"+	search_film.getDescription()+"\t"+search_film.getSpecial_Features()+"\t"+search_film.getCategory()+"\t"+search_film.getRelease_Year()+"\t"+search_film.getRental_Duration()+"\t"+search_film.getReplacement_Cost()+"\t"+search_film.getLength()+"\t"+search_film.getRatings());
						}System.out.println("Do you want to search again(y/n)");
						choice3=sc.next();
						}while(choice3.charAt(0)=='y'||choice3.charAt(0)=='Y');
					break;
		
		case 6:	
				//for exiting
				System.exit(0);
				break;
		}System.out.println("Do you want to continue(y/n)");
		choice1=sc.next();
		}while(choice1.charAt(0)=='Y'||choice1.charAt(0)=='y');

	}


	//main menu of Film management system
	public static void menuSelection()
	{
		System.out.println("\t\t\tFilm Management System");
		System.out.println("MENU");
		System.out.println("1. Add Film");
		System.out.println("2. Modify Film Info");
		System.out.println("3. Remove Film");
		System.out.println("4. View all Film (Film summary)");
		System.out.println("5. Search Film ");
		System.out.println("6. Exit");
	}
	
	
	
	//remove menu for film
	public static void menuRemoveSelection()
	{
		
		System.out.println("\t\t Remove Menu");
		System.out.println("1. Remove Film by Rating");
		System.out.println("2. Remove Film by Film Name");
		System.out.println("3. Remove Film by Release Year");
		
		
	}
	//modify menu for film
	public static void menuModifySelection()
	{
		
		System.out.println("\t\t Modify Menu");
		System.out.println("1. Modify Film by Rating");
		System.out.println("2. Modify Film by Film Name");
		System.out.println("3. Modify Film by Release Year");
		
		
	}
}
