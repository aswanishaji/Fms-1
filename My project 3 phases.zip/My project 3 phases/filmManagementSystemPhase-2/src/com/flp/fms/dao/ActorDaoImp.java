package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.flp.fms.domain.Actor;

public class ActorDaoImp implements IActorDao{

	//establishing and getting connection with database called "fms"
public Connection getConnection()
{	
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fms","root","Pass1234");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return connection;
	}
	
	

//displaying the actors 
	@Override
	public Set<Actor> displayActors() {
		Connection con=getConnection();	
		Set<Actor> actors=new HashSet<Actor>();
		//using sql query retriving the actors in the database
		 String sql="select * from actor";
			try {
				PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					actors.add(new Actor(rs.getInt(1),rs.getString(2),rs.getString(3)));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return actors;
	}

}
